package com.everis.alicante.courses.beca.summer17.friendsnet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FriendsnetApplication {

	public static void main(String[] args) {
		SpringApplication.run(FriendsnetApplication.class, args);
	}
}
